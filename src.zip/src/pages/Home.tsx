import React from "react";

const Home: React.FC = () => {
	return (
		<div>
			<h1>WELCOME TO THE CALENDAR APP</h1>
			<p>NAVIGATE TO THE CALENDAR PAGE</p>
		</div>
	);
};

export default Home;
